# CyberSafe Website — Beginner Setup Guide

## What is included
- `index.html`: complete responsive website (HTML, CSS, JavaScript)
- Learning cards about phishing, passwords, scams, and privacy
- Five-question interactive quiz with score and explanations
- Demo admin content manager
- Browser-local storage for demo modules and quiz scores

## Run it on your computer
1. Download and extract `CyberSafe_Project.zip`.
2. Install Visual Studio Code from https://code.visualstudio.com/
3. In VS Code, choose **File → Open Folder** and select the extracted `CyberSafe_Project` folder.
4. Open `index.html`.
5. If you have the Live Server extension, right-click `index.html` and select **Open with Live Server**. Otherwise, open `index.html` directly in your browser.
6. Test the Learn, Safety Tips, Quiz, and Admin Demo sections.
7. Demo admin PIN: `SAFE2026`.

## Publish it free with Netlify (manual deploy)
1. Open https://www.netlify.com/ and create/sign in to an account.
2. In the Netlify dashboard, choose **Add new site** or **Deploy manually** (the wording may vary).
3. Drag and drop the extracted folder that contains `index.html` into the manual deploy area. If the site uploader expects a folder archive, zip the contents so `index.html` is at the ZIP root, then upload it.
4. Wait for deployment to finish.
5. Open the generated `https://....netlify.app` URL and test the website on your phone.
6. To update the site, make changes to `index.html` and deploy the updated files again.

## Important project limitations
This starter version is a front-end demonstration, not a production-ready system:
- Admin PIN is visible in JavaScript and can be bypassed. Do not use it to protect real admin access.
- Module edits and quiz scores are stored in the visitor's own browser (`localStorage`), not in a shared database. Other visitors will not see your changes.
- It does not collect student names, email addresses, or passwords.
- Do not enter real personal or sensitive information.

## For a full database-backed version
For real user accounts, shared educational content, and shared quiz results, connect Supabase:
1. Create a Supabase project at https://supabase.com/.
2. Create database tables for modules, quiz results, and admin roles.
3. Enable Supabase Auth for user sign-in.
4. Configure Row Level Security (RLS) policies so only authorized admins can edit modules and users can read/write only permitted records.
5. Use a server-enforced admin role; never rely on a secret or admin password stored in front-end JavaScript.
6. Add the Supabase project URL and publishable/anon key to the website. Never put a service-role key in browser code.

For a beginner BSIT project, this version is suitable as a working prototype and can be extended with Supabase after the front-end is understood.
